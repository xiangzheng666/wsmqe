import numpy as np
from tqdm import tqdm
from transformers import BertTokenizer, TFBertForMaskedLM
import tensorflow as tf

model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = TFBertForMaskedLM.from_pretrained(model_name)

def parse_example(example_proto):
        """
        Parses an example proto and returns tensors for each feature.
        """
        feature_description = {
            'x': tf.io.FixedLenFeature([], tf.string),
            'x_mask': tf.io.FixedLenFeature([], tf.string),
            'y': tf.io.FixedLenFeature([], tf.string),
        }
        parsed_example = tf.io.parse_single_example(example_proto, feature_description)
        parsed_example['x'] = tf.io.decode_raw(parsed_example['x'], out_type=tf.int64)
        parsed_example['x_mask'] = tf.io.decode_raw(parsed_example['x_mask'], out_type=tf.int64)
        parsed_example['y'] = tf.io.decode_raw(parsed_example['y'], out_type=tf.int64)

        return parsed_example['x'], parsed_example['x_mask'], parsed_example['y']

def _bytes_feature(value):
    return tf.train.Feature(bytes_list=tf.train.BytesList(value=[np.array(value).astype(np.int64).tostring()]))

def serialize_example(x,x_mask, y):
    """
    Creates a tf.Example message ready to be written to a file.
    """
    # Create a dictionary mapping the feature name to the tf.Example-compatible data type.
    feature = {
        'x': _bytes_feature(x),
        'x_mask': _bytes_feature(x_mask),
        'y': _bytes_feature(y),
    }

    # Create a Features message using tf.train.Example.
    example_proto = tf.train.Example(features=tf.train.Features(feature=feature))
    return example_proto.SerializeToString()

def mask_token(tokens):
    masked_tokens = []
    for token in tokens:
        if np.random.rand() < 0.15:
            if np.random.rand() < 0.8:
                masked_tokens.append(tokenizer.mask_token_id)
            elif np.random.rand() < 0.5:
                masked_tokens.append(np.random.randint(len(tokenizer)))
            else:
                masked_tokens.append(token)
        else:
            masked_tokens.append(token)
    return masked_tokens

def to_record():
    with open("../desc_filter.txt",'r',encoding='utf-8') as f1:
        data=f1.readlines()
        with tf.io.TFRecordWriter('train.tfrecord') as writer:
            for i in tqdm(data[:-1000]):
                no_mask_input_id=tokenizer.encode(i)[:30]
                input_id=mask_token(no_mask_input_id)
                length = len(input_id)
                input_mask = [1] * length
                if length<30:
                    input_id.extend([0]*(30-length))
                    input_mask.extend([0] * (30 - length))
                    no_mask_input_id.extend([0] * (30 - length))
                example = serialize_example(input_id,input_mask,no_mask_input_id)
                writer.write(example)
        with tf.io.TFRecordWriter('test.tfrecord') as writer:
            for i in tqdm(data[-1000:]):
                no_mask_input_id=tokenizer.encode(i)[:30]
                input_id=mask_token(no_mask_input_id)
                length = len(input_id)
                input_mask = [1] * length
                if length<30:
                    input_id.extend([0]*(30-length))
                    input_mask.extend([0] * (30 - length))
                    no_mask_input_id.extend([0] * (30 - length))
                example = serialize_example(input_id,input_mask,no_mask_input_id)
                writer.write(example)

to_record()
