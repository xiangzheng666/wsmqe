import re
from tqdm import tqdm

def filter(s):
    return re.sub("[python|java|C++]","",s)
with open("desc.txt",'r+',encoding='utf-8') as f:
    data = [filter(i).split(' ') for i in tqdm(f.readlines()[:-1])]
data = [" ".join(i) for i in tqdm(data) if len(i)>10]
with open("desc_filter.txt",'w+',encoding='utf-8') as f:
    f.write("\n".join(data))