import re

import numpy as np
from gensim import corpora
from tqdm import tqdm
from transformers import RobertaTokenizer
import tensorflow as tf


def to_record():

    with open("vocab10000.json", "r+", encoding='utf-8') as f:
        word2id = eval(f.read())
    def _bytes_feature(value):
        return tf.train.Feature(bytes_list=tf.train.BytesList(value=[np.array(value).astype(np.int64).tostring()]))
    def serialize_example(x, x_mask, y):
        """
        Creates a tf.Example message ready to be written to a file.
        """
        # Create a dictionary mapping the feature name to the tf.Example-compatible data type.
        feature = {
            'x': _bytes_feature(x),
            'x_mask': _bytes_feature(x_mask),
            'y': _bytes_feature(y),
        }

        # Create a Features message using tf.train.Example.
        example_proto = tf.train.Example(features=tf.train.Features(feature=feature))
        return example_proto.SerializeToString()
    with open("desc_token.txt",'r',encoding='utf-8') as f1:
        data=f1.readlines()
        with tf.io.TFRecordWriter('train.tfrecord') as writer:
            for i in tqdm(data[:-1000]):
                input_id=[word2id[word] for word in i.split()[:30]]
                length = len(input_id)
                input_mask = [1] * length
                if length<30:
                    input_id.extend([0]*(30-length))
                    input_mask.extend([0] * (30 - length))
                example = serialize_example(input_id[:-1],input_mask[:-1],input_id[1:])
                writer.write(example)
        with tf.io.TFRecordWriter('test.tfrecord') as writer:
            for i in tqdm(data[-1000:]):
                input_id=[word2id[word] for word in i.split()[:30]]
                length = len(input_id)
                input_mask = [1] * length
                if length<30:
                    input_id.extend([0]*(30-length))
                    input_mask.extend([0] * (30 - length))
                example = serialize_example(input_id[:-1],input_mask[:-1],input_id[1:])
                writer.write(example)

def token():
    tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
    def tokenit(txt):
        return " ".join([re.sub("Ġ|Ċ", "", i) for i in tokenizer.tokenize(txt)]).lower()
    with  open("../desc.txt", "r+", encoding='utf-8') as f:
        with open("desc_token.txt", "w+", encoding='utf-8') as f1:
            for i in tqdm(f.readlines()):
                t=tokenit(i)
                f1.write(t+'\n')


def get_vocab():
    path='desc_token.txt'
    text=[]
    with open(path, "r+", encoding='utf-8') as f:
        for i in tqdm(f.readlines()):
            text.append(re.sub('\n','',i).split())
    special_tokens = ['<empty>', '<oov>']
    dictionary = corpora.Dictionary()
    for token in special_tokens:
        dictionary.token2id[token] = len(dictionary.token2id)
    dictionary.add_documents(text)
    dictionary.filter_extremes(no_below=3, no_above=1, keep_n=10000, keep_tokens=special_tokens)

    with open("vocab10000.json","w+", encoding='utf-8') as f:
        f.write(str(dictionary.token2id))

    with open('desc_token.txt',"w+", encoding='utf-8') as f:
        for line in tqdm(text):
            tmp=[]
            for i in line:
                if i in dictionary.token2id.keys():
                    tmp.append(i)
                else:
                    tmp.append("<oov>")
            f.write(" ".join(tmp)+'\n')

token()
get_vocab()
to_record()
