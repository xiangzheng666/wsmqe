import tensorflow as tf

gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
tf.config.experimental.set_visible_devices(devices=gpus[1], device_type='GPU')

with open("../../dataset/train_data/python/docstring_tokens_vocab.txt",'r',encoding='utf-8') as f:
    vocab=f.read().split("\n")
    table = tf.lookup.StaticVocabularyTable(tf.lookup.KeyValueTensorInitializer(vocab, tf.range(len(vocab),dtype=tf.int64)),num_oov_buckets=1)



def mapfunc(x):
    
    wordid=tf.cast(table.lookup(tf.strings.split(x,sep=" ")), tf.int32)
    wordid=tf.where(tf.equal(wordid, 10000), 1 * tf.ones_like(wordid), wordid)
    wordid = wordid[:60]
    wordid = tf.pad(wordid, [[0, 60 - tf.shape(wordid)[0]]])
    return x,wordid

def getdata():
    y=tf.data.TextLineDataset("../../dataset/MLP_data/desc.txt").map(mapfunc)
    x=tf.data.TextLineDataset("../../dataset/MLP_data/qurey.txt").map(mapfunc)
    x1=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-1.txt").map(mapfunc)
    x2=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-2.txt").map(mapfunc)
    x3=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-3.txt").map(mapfunc)
    data=tf.data.Dataset.zip((x,x1,x2,x3,y))
    return data.take(390807),data.take(10000)

#input_id = tokenizer.encode(convertstr(i), return_tensors='tf')
if __name__=="__main__":
    
    train_data,test_data=getdata()
    for i in test_data.take(1):
        print(i)