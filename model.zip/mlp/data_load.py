import tensorflow as tf

with open("../../dataset/train_data/python/docstring_tokens_vocab.txt",'r',encoding='utf-8') as f:
    vocab=f.read().split("\n")
    table = tf.lookup.StaticVocabularyTable(tf.lookup.KeyValueTensorInitializer(vocab, tf.range(len(vocab),dtype=tf.int64)),num_oov_buckets=1)

def mapfunc(x):
    wordid=tf.cast(table.lookup(tf.strings.split(x,sep=" ")), tf.int32)
    wordid=tf.where(tf.equal(wordid, 10000), 1 * tf.ones_like(wordid), wordid)
    wordid = wordid[:60]
    wordid = tf.pad(wordid, [[0, 60 - tf.shape(wordid)[0]]])
    return wordid

def getdata():
    y=tf.data.TextLineDataset("../../dataset/MLP_data/desc.txt").map(mapfunc)
    x=tf.data.TextLineDataset("../../dataset/MLP_data/qurey.txt").map(mapfunc)
    x1=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-1.txt").map(mapfunc)
    x2=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-2.txt").map(mapfunc)
    x3=tf.data.TextLineDataset("../../dataset/MLP_data/keyword-3.txt").map(mapfunc)

    data=tf.data.Dataset.zip((x,x1,x2,x3,y))
    return data.skip(1000),data.take(1000)

if __name__=="__main__":
    def convertstr(tf_string):
        py_string = str(tf_string.numpy(), 'utf-8')
        return py_string
    #tf.config.experimental.set_visible_devices(devices=gpus[0], device_type='GPU')
    from transformers import BertTokenizer, TFBertForMaskedLM,RobertaTokenizer
    model_name = 'bert-base-uncased'
    tokenizer = BertTokenizer.from_pretrained(model_name)
    model = TFBertForMaskedLM.from_pretrained("./last_model",output_hidden_states=True)
    
    test_data=tf.data.TextLineDataset("../../dataset/MLP_data/token.txt")
    for i in test_data.take(1):
        input_id = tokenizer.encode(convertstr(i), return_tensors='tf')
        output = model(input_id)[-1][-1]
        print(output)