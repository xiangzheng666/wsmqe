import tensorflow as tf
from transformers import RobertaTokenizer

tokenizer = RobertaTokenizer.from_pretrained("roberta-base")

def mapfunc(x):
    return tf.cast(x, tf.int32)

def preprocess(x):
    x_str = x.decode("utf-8")
    wordid = tokenizer.encode(x_str, truncation=True, padding='max_length', max_length=60, return_tensors='tf')[0]
    return wordid

def getdata():
    y = tf.data.TextLineDataset("../../dataset/MLP_data/desc.txt").map(mapfunc)
    x = tf.data.TextLineDataset("../../dataset/MLP_data/qurey.txt").map(mapfunc)
    x1 = tf.data.TextLineDataset("../../dataset/MLP_data/keyword-1.txt").map(mapfunc)
    x2 = tf.data.TextLineDataset("../../dataset/MLP_data/keyword-2.txt").map(mapfunc)
    x3 = tf.data.TextLineDataset("../../dataset/MLP_data/keyword-3.txt").map(mapfunc)

    y = y.map(lambda x: tf.py_function(preprocess, [x], Tout=tf.int32))
    x = x.map(lambda x: tf.py_function(preprocess, [x], Tout=tf.int32))
    x1 = x1.map(lambda x: tf.py_function(preprocess, [x], Tout=tf.int32))
    x2 = x2.map(lambda x: tf.py_function(preprocess, [x], Tout=tf.int32))
    x3 = x3.map(lambda x: tf.py_function(preprocess, [x], Tout=tf.int32))

    data = tf.data.Dataset.zip((x, x1, x2, x3, y))
    return data.skip(1000), data.take(1000)

if __name__ == "__main__":
    train_data, test_data = getdata()
    
    for i in test_data.take(1):
        print(i[0])