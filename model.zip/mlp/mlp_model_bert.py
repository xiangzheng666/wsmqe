import sys 
sys.path.append("/root/data1/lxz/start/model/mlp")
from UNFI_model import UNFI 
from tensorflow import keras
from transformers import BertTokenizer, TFBertForMaskedLM
from tensorflow.keras.layers import Dense, Concatenate
import tensorflow as tf

def convertstr(tf_string):
    py_string = str(tf_string.numpy(), 'utf-8')
    return py_string

class mlp(keras.Model):

    def __init__(self):
        super(mlp, self).__init__()
        self.embingmodel=UNFI()
        self.embingmodel.trainable=False
        self.embingmodel.load_weights("/root/data1/lxz/start/model/save_model/UNIF/python/UNIF.pth").expect_partial()

        self.model_name = 'bert-base-uncased'
        self.tokenizer = BertTokenizer.from_pretrained(self.model_name)
        self.model = TFBertForMaskedLM.from_pretrained("./last_model",output_hidden_states=True)
        self.model.trainable=False

        self.dense1 = Dense(100, activation='linear')
        self.dense2 = Dense(100, activation='linear')
        self.dense3 = Dense(100, activation='linear')
    def bert_code(self,words):
        input_id = tokenizer.encode(convertstr(words), return_tensors='tf')
    def sumvect(self,inputs):
        data,data1,data2,data3=inputs
        data1=self.dense1(data1)
        data2=self.dense2(data2)
        data3=self.dense3(data3)
        return tf.reduce_sum([data,data1,data2,data3],axis=0)

    def call(self, inputs, training=None, mask=None):
        data,data1,data2,data3,y=inputs
        data=self.embingmodel.desc_present(data)
        data1=self.embingmodel.desc_present(data1)
        data2=self.embingmodel.desc_present(data2)
        data3=self.embingmodel.desc_present(data3)
        return self.sumvect([data,data1,data2,data3]),self.embingmodel.desc_present(y)

    def getvect(self, inputs):
        data,data1,data2,data3=inputs
        data=self.embingmodel.desc_present(data)
        data1=self.embingmodel.desc_present(data1)
        data2=self.embingmodel.desc_present(data2)
        data3=self.embingmodel.desc_present(data3)
        return self.sumvect([data,data1,data2,data3])
