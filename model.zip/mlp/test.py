import tensorflow as tf
import numpy as np

from mlp_model import mlp 
from tensorflow import keras
from data_load import getdata
from tqdm import tqdm
mlp=mlp()
try:
    mlp.load_weights("model/lastmlp")
    print("load model sucess")
except:
    pass
train_data,test_data=getdata()


x = tf.constant([1, 2, 3], dtype=tf.float32)
y = tf.constant([4, 5, 6], dtype=tf.float32)
cosine_similarity = tf.keras.losses.cosine_similarity(x, y)
print(cosine_similarity.numpy()) 

def simlity_loss(pre,y):
    good_score=tf.keras.losses.cosine_similarity(pre,y,axis=1)
    return  tf.reduce_mean(good_score)+1

optimizer=tf.keras.optimizers.Adamax()
bs=100
for epoch in range(100):
    train_epoch_loss=[]
    for (keyword,ex1,ex2,ex3,y) in tqdm(train_data.batch(bs),total=4000/bs+1):
        with tf.GradientTape() as tape:
            pre,y=mlp([keyword,ex1,ex2,ex3,y])
            batch_loss=simlity_loss(pre,y)
        grad = tape.gradient(batch_loss, mlp.trainable_variables)
        optimizer.apply_gradients(zip(grad, mlp.trainable_variables))
        train_epoch_loss.append(batch_loss.numpy())
    
    test_epoch_loss=[]
    for (keyword,ex1,ex2,ex3,y) in tqdm(test_data.batch(bs),total=1000/bs):
        with tf.GradientTape() as tape:
            pre,y=mlp([keyword,ex1,ex2,ex3,y])
            batch_loss=simlity_loss(pre,y)
        grad = tape.gradient(batch_loss, mlp.trainable_variables)
        optimizer.apply_gradients(zip(grad, mlp.trainable_variables))
        test_epoch_loss.append(batch_loss.numpy())
    
    mlp.save_weights("model/lastmlp",overwrite=True)
    print(epoch,' train_loss: ',np.mean(train_epoch_loss),' test_loss: ',np.mean(test_epoch_loss))
