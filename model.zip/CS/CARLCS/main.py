import argparse
import random

from tqdm import tqdm
from data_load import *
from carlcs_model import CARLCS
import tensorflow as tf


def train():
    paser = argparse.ArgumentParser(prog="t",
                                    description="t",
                                    usage="t",
                                    epilog='t');
    paser.add_argument('-l', dest='language', default='python_model',help='', type=str, required=False)
    paser.add_argument('-bs', dest='bs', default='128',help='', type=str, required=False)
    paser.add_argument('-gpu', dest='gpu', help='',default='0', type=str, required=False)
    args = paser.parse_args()

    language = args.language

    gpus = tf.config.experimental.list_physical_devices('GPU')
    for gpu in gpus:
       tf.config.experimental.set_memory_growth(gpu, True)

    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    tf.config.experimental.set_visible_devices(devices=gpus[int(args.gpu)], device_type='GPU')

    model=CARLCS()
    try:
        model.load_weights("../../save_model/CARLCS/"+language+"/CARLCS.pth")
        print("load save_model sucess")
    except:
        pass
    valid_num,valid_db = get_valid_dataset(language,bs=1000)
    test_num,test_db = get_test_dataset(language,bs=1000)
    optimizer=tf.keras.optimizers.Adamax()
    def simlity_loss(code_out,desc_out,neg_code_out,neg_desc_out):
        neg_score=tf.keras.losses.cosine_similarity(neg_code_out,neg_desc_out ,axis=1)  # [batchsize]
        good_score=tf.keras.losses.cosine_similarity(code_out,desc_out ,axis=1)
        return  tf.reduce_mean(tf.clip_by_value(tf.add(good_score-neg_score,0.5),0,10))

    def comput_mrr(list_t):
        mrr=[]
        for index,i in enumerate(list_t):
            i=i.numpy().tolist()
            target=i[index]
            i.sort()
            mrr.append(1/(i.index(target)+1))
        return np.mean(mrr)

    def comput_topk(list_t,k):
        topk = []
        for index, i in enumerate(list_t):
            i = i.numpy().tolist()
            target = i[index]
            i.sort()
            if i.index(target)<= k-1:
                topk.append(1)
            else:
                topk.append(0)
        return np.mean(topk)

    score=0
    for epoch in range(400):
        num, train_db = get_train_dataset(language,bs=int(args.bs))
        loss_score = []
        with tqdm(total=int(num+1)) as pbar:
            for code, fun_name, desc, neg_desc in train_db:
                pbar.update(1)
                with tf.GradientTape() as tape:
                    code_out,desc_out,neg_code_out,neg_desc_out=model([code, fun_name, desc, neg_desc])
                    epoch_loss=simlity_loss(code_out,desc_out,neg_code_out,neg_desc_out)
                grad = tape.gradient(epoch_loss, model.trainable_variables)
                optimizer.apply_gradients(zip(grad, model.trainable_variables))
                loss_score.append(epoch_loss.numpy())

        valid_mrr = []
        valid_topk = []
        with tqdm(total=int(valid_num + 1)) as pbar:
            for code, fun_name, desc, neg_desc in valid_db:
                pbar.update(1)
                tmp=model.qurey([code, fun_name, desc])
                valid_mrr.append(comput_mrr(tmp))
                k_tmp = []
                for k in range(10):
                    score_k = comput_topk(tmp, k + 1)
                    k_tmp.append(score_k)
                valid_topk = k_tmp
                break

            print("epoch:", epoch, "loss:", np.mean(loss_score), "valid_mrr:", np.mean(valid_mrr))
            for k in range(10):
                print("valid:@precison", k + 1, ":", valid_topk[k])

        test_mrr = []
        test_topk = []
        with tqdm(total=int(test_num + 1)) as pbar:
            for code, fun_name, desc, neg_code_desc in test_db:
                pbar.update(1)
                tmp = model.qurey([code, fun_name, desc])
                test_mrr.append(comput_mrr(tmp))
                k_tmp = []
                for k in range(10):
                    score_k = comput_topk(tmp, k + 1)
                    k_tmp.append(score_k)
                test_topk = k_tmp
                break

        print("test_mrr:", np.mean(test_mrr))
        for k in range(10):
            print("test:@precison", k + 1, ":", test_topk[k])

        if np.mean(test_mrr) > score:
            score = np.mean(test_mrr)
            model.save_weights("../../save_model/CARLCS/" + language + "/CARLCS.pth", overwrite=True)

if __name__ == '__main__':
    train()