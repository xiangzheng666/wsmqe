import os.path

import tensorflow as tf
import numpy as np


# Read TFRecord file
def parse_example(example_proto):
    """
    Parses an example proto and returns tensors for each feature.
    """
    feature_description = {
        'code': tf.io.FixedLenFeature([], tf.string),
        'func': tf.io.FixedLenFeature([], tf.string),
        'code_desc': tf.io.FixedLenFeature([], tf.string),
        'neg_code_desc': tf.io.FixedLenFeature([], tf.string)
    }
    parsed_example = tf.io.parse_single_example(example_proto, feature_description)
    parsed_example['code'] = tf.io.decode_raw(parsed_example['code'], out_type=tf.int64)
    parsed_example['func'] = tf.io.decode_raw(parsed_example['func'], out_type=tf.int64)
    parsed_example['code_desc'] = tf.io.decode_raw(parsed_example['code_desc'], out_type=tf.int64)
    parsed_example['neg_code_desc'] = tf.io.decode_raw(parsed_example['neg_code_desc'], out_type=tf.int64)

    return parsed_example['code'],parsed_example['func'],parsed_example['code_desc'],parsed_example['neg_code_desc']


def get_train_dataset(language,bs):
    return 392724/bs,tf.data.TFRecordDataset("../../../dataset/train_data/"+language+"/train/" + "data.tfrecord").map(parse_example).batch(bs, drop_remainder=True)

def get_valid_dataset(language,bs):
    return 21742/1000,tf.data.TFRecordDataset("../../../dataset/train_data/"+language+"/valid/" + "data.tfrecord").map(parse_example).batch(bs, drop_remainder=True)

def get_test_dataset(language,bs):
    return 21476/1000,tf.data.TFRecordDataset("../../../dataset/train_data/"+language+"/test/" + "data.tfrecord").map(parse_example).batch(bs, drop_remainder=True)

