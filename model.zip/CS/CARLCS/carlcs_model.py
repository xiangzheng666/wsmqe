from tensorflow import keras
from tensorflow_core.python.keras.layers import Lambda
from tensorflow.keras import backend as K
import tensorflow as tf
import numpy as np

canshu=100
class AttentionLayer(keras.layers.Layer):
    def __init__(self, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        if not isinstance(input_shape, list) or len(input_shape) != 2:
            raise ValueError('An attention layer should be called '
                             'on a list of 2 inputs.')
        if not input_shape[0][2] == input_shape[1][2]:
            raise ValueError('Embedding sizes should be of the same size')

        self.kernel = self.add_weight(shape=(input_shape[0][2], input_shape[0][2]),
                                      initializer='glorot_uniform',
                                      name='kernel',
                                      trainable=True)

        super(AttentionLayer, self).build(input_shape)

    def call(self, inputs):
        a = K.dot(inputs[0], self.kernel)
        y_trans = K.permute_dimensions(inputs[1], (0, 2, 1))
        b = K.batch_dot(a, y_trans, axes=[2, 1])
        return K.tanh(b)

    def compute_output_shape(self, input_shape):
        return (None, input_shape[0][1], input_shape[1][1])

class CARLCS(keras.Model):
    def __init__(self,bs=canshu):
        super(CARLCS, self).__init__()

        self.maxpool = Lambda(lambda x: K.max(x, axis=1, keepdims=False), output_shape=lambda x: (x[0], x[2]),
                              name='maxpool_methname')
        self.bs=bs
        # ---------------funcname_repersent-----------------------
        self.funcname_embeding = keras.layers.Embedding(10000, 100)
        self.funcname_embeding_dropout = keras.layers.Dropout(0.25)
        self.methname_conv1 = keras.layers.Conv1D(100,2,padding='valid', activation='relu',strides=1)
        self.methname_conv2 = keras.layers.Conv1D(100, 3, padding='valid', activation='relu', strides=1)
        self.methname_conv3 = keras.layers.Conv1D(100, 4, padding='valid', activation='relu', strides=1)
        self.funcname_dropout_conv = keras.layers.Dropout(0.25)
        # ---------------code_repersent-----------------------
        self.code_embeding = keras.layers.Embedding(10000, 100)
        self.code_embeding_dropout = keras.layers.Dropout(0.25)
        self.tokens_conv1 = keras.layers.Conv1D(100, 2, padding='valid', activation='relu', strides=1, name='tokens_conv1')
        self.tokens_conv2 = keras.layers.Conv1D(100, 3, padding='valid', activation='relu', strides=1, name='tokens_conv2')
        self.tokens_conv3 = keras.layers.Conv1D(100, 4, padding='valid', activation='relu', strides=1, name='tokens_conv3')
        self.code_dropout_conv = keras.layers.Dropout(0.25)
        # ---------------code_desc_repersent-----------------------
        self.code_desc_embeding = keras.layers.Embedding(10000, 100)
        self.code_desc_embeding_dropout = keras.layers.Dropout(0.25)
        self.desc_conv1 = keras.layers.Conv1D(100, 2, padding='valid', activation='relu', strides=1, name='desc_conv1')
        self.desc_conv2 = keras.layers.Conv1D(100, 3, padding='valid', activation='relu', strides=1, name='desc_conv2')
        self.desc_conv3 = keras.layers.Conv1D(100, 4, padding='valid', activation='relu', strides=1, name='desc_conv3')
        self.code_desc_dropout_conv = keras.layers.Dropout(0.25)
        #-----------------ap----------------------------------
        self.attention = AttentionLayer(name='attention_layer')
        self.gmp_1 = keras.layers.GlobalMaxPooling1D(name='blobalmaxpool_colum')
        self.dot1= keras.layers.Dot(axes=1,normalize=False,name='column_dot')
        self.attention_trans_layer = Lambda(lambda x: K.permute_dimensions(x, (0,2,1)),name='trans_attention')
        self.gmp_2 = keras.layers.GlobalMaxPooling1D(name='blobalmaxpool_colum')
        self.dot2 = keras.layers.Dot(axes=1, normalize=False, name='row_dot')

    def funcname_repersent(self, funcname):
        funcname=self.funcname_embeding_dropout(self.funcname_embeding(funcname))
        methname_conv1_out = self.methname_conv1(funcname)
        methname_conv2_out = self.methname_conv2(funcname)
        methname_conv3_out = self.methname_conv3(funcname)
        methname_conv1_dropout = self.funcname_dropout_conv(methname_conv1_out)
        methname_conv2_dropout = self.funcname_dropout_conv(methname_conv2_out)
        methname_conv3_dropout = self.funcname_dropout_conv(methname_conv3_out)
        funcname=keras.layers.concatenate([methname_conv1_dropout,methname_conv2_dropout,methname_conv3_dropout],axis=1)
        return funcname
    def code_repersent(self, code):
        code=self.code_embeding_dropout(self.code_embeding(code))
        tokens_conv1_out = self.tokens_conv1(code)
        tokens_conv2_out = self.tokens_conv2(code)
        tokens_conv3_out = self.tokens_conv3(code)
        tokens_conv1_dropout = self.code_dropout_conv(tokens_conv1_out)
        tokens_conv2_dropout = self.code_dropout_conv(tokens_conv2_out)
        tokens_conv3_dropout = self.code_dropout_conv(tokens_conv3_out)
        code=keras.layers.concatenate([tokens_conv1_dropout,tokens_conv2_dropout,tokens_conv3_dropout],axis=1)
        return code
    def desc_repersent(self, code_desc):
        code_desc=self.code_desc_embeding_dropout(self.code_desc_embeding(code_desc))
        desc_conv1_out = self.desc_conv1(code_desc)
        desc_conv2_out = self.desc_conv2(code_desc)
        desc_conv3_out = self.desc_conv3(code_desc)
        desc_conv1_dropout = self.code_desc_dropout_conv(desc_conv1_out)
        desc_conv2_dropout = self.code_desc_dropout_conv(desc_conv2_out)
        desc_conv3_dropout = self.code_desc_dropout_conv(desc_conv3_out)
        code_desc=keras.layers.concatenate([desc_conv1_dropout,desc_conv2_dropout,desc_conv3_dropout],axis=1)
        return code_desc
    def concate(self,code,fun_name):
        return keras.layers.concatenate([code,fun_name], axis=1)

    def decoder(self,inputs):
        code, fun_name, desc = inputs

        code = self.concate(self.code_repersent(code), self.funcname_repersent(fun_name))
        desc = self.desc_repersent(desc)

        attention_out = self.attention([code, desc])
        att_1 = self.gmp_1(attention_out)
        att_1_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_1)
        desc_out = self.dot1([att_1_next, desc])
        attention_transposed = self.attention_trans_layer(attention_out)
        att_2 = self.gmp_2(attention_transposed)
        att_2_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_2)
        code_out = self.dot2([att_2_next, code])

        return code_out,desc_out

    def repersent(self,inputs):
        code, fun_name, desc = inputs
        code = self.concate(self.code_repersent(code), self.funcname_repersent(fun_name))
        desc = self.desc_repersent(desc)

        attention_out = self.attention([code, desc])
        att_1 = self.gmp_1(attention_out)
        att_1_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_1)
        desc_out = self.dot1([att_1_next, desc])
        attention_transposed = self.attention_trans_layer(attention_out)
        att_2 = self.gmp_2(attention_transposed)
        att_2_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_2)
        code_out = self.dot2([att_2_next, code])

        return code_out,desc_out

    def decoder_moredesc(self,inputs):
        code, fun_name, desc,more_desc = inputs
        code = self.concate(self.code_repersent(code), self.funcname_repersent(fun_name))
        desc = self.desc_repersent(desc)
        more_desc = [self.desc_repersent(i) for i in more_desc]###

        attention_out = self.attention([code, desc])
        more_desc_att=[self.attention([code, i]) for i in more_desc]##
        more_desc_next=[keras.layers.Activation('softmax', name='AP_active_colum')(self.gmp_1(i)) for i in more_desc_att]##
        att_1 = self.gmp_1(attention_out)
        att_1_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_1)
        more_desc_out=[self.dot1([i,j]) for i,j in zip(more_desc_next,more_desc)]
        desc_out = self.dot1([att_1_next, desc])
        for i in more_desc_out:
            desc_out=desc_out+i
        attention_transposed = self.attention_trans_layer(attention_out)
        att_2 = self.gmp_2(attention_transposed)
        att_2_next = keras.layers.Activation('softmax', name='AP_active_colum')(att_2)
        code_out = self.dot2([att_2_next, code])

        return code_out,desc_out

    def call(self, inputs, training=None, mask=None):
        code, fun_name, desc, neg_desc = inputs
        code_out,desc_out=self.decoder([code, fun_name, desc])
        neg_code_out,neg_desc_out=self.decoder([code, fun_name, neg_desc])
        return code_out,desc_out,neg_code_out,neg_desc_out

    def sim_cosin(self,vect):
        return tf.keras.losses.cosine_similarity(vect[0],vect[1])

    def qurey(self,input):
        code, fun_name, desc = input
        lis = [self.sim_cosin(self.decoder([code, fun_name, tf.broadcast_to(tf.expand_dims(i, axis=0),[self.bs, 60])])) for i in desc]
        return lis


    def eval(self,input,more=None):
        code, fun_name, desc = input
        if not more:
            lis = [self.sim_cosin(self.decoder([code, fun_name, tf.broadcast_to(tf.expand_dims(i, axis=0), [self.bs, 60])])) for i in desc]
        else:
            sortednum, simirity, source = more
            lis = [self.sim_cosin(self.decoder_moredesc([code,
                                                         fun_name,
                                                         tf.broadcast_to(tf.expand_dims(i, axis=0), [self.bs, 60]),
                                                        [tf.broadcast_to(tf.expand_dims(source[int(j),:], axis=0), [self.bs, 60]) for j in sortednum[:,0]]])
                                  ) for i in desc]
        return lis
    def convert(self,inputs):
        inputs = tf.tile(inputs, [canshu//inputs.shape[0]+1, 1])
        return tf.slice(inputs, [0, 0], [canshu, 60])

    def evalGPT(self,inputs,b=0):
        code, func, qurey, qurey_o=inputs
        n=qurey_o.shape[0]
        code_vect, desc_o_vect = self.decoder([code, func, self.convert(qurey_o)])
        desc_o_vect=tf.slice(desc_o_vect, [0, 0], [n, 100])

        desc_vect = [tf.slice(self.decoder([code, func, self.convert(i)])[1],[0, 0], [n, 100]) for i in qurey]

        scorelist = [[tf.clip_by_value(-tf.keras.losses.cosine_similarity(i, j), 0, 1).numpy() for i, j in
                      zip(desc, desc_o_vect)] for desc in desc_vect]
        scorelist.append([1 for _ in range(len(scorelist[0]))])

        scorelist = tf.cast(tf.nn.softmax(np.array(scorelist), axis=0), dtype=tf.float32)

        for i in range(len(scorelist) - 1):
            desc_o_vect = desc_o_vect + tf.expand_dims(scorelist[i], axis=-1) * desc_vect[i]

        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in desc_o_vect]