import argparse

from tqdm import tqdm
from data_load import *
from UNFI_model import UNFI

def comput_mrr(list_t):
    mrr=[]
    for index,i in enumerate(list_t):
        i=i.numpy().tolist()
        target=i[index]
        i.sort()
        mrr.append(1/(i.index(target)+1))
    return np.mean(mrr)

def comput_topk(list_t,k):
    topk = []
    for index, i in enumerate(list_t):
        i = i.numpy().tolist()
        target = i[index]
        i.sort()
        if i.index(target)<= k-1:
            topk.append(1)
        else:
            topk.append(0)
    return np.mean(topk)

def test():
    paser = argparse.ArgumentParser(prog="t",
                                    description="t",
                                    usage="t",
                                    epilog='t');
    paser.add_argument('-l', dest='language', default='java', help='', type=str, required=False)
    paser.add_argument('-gpu', dest='gpu', help='', default='0', type=str, required=False)
    paser.add_argument('-bs', dest='bs', default='100', help='', type=str, required=False)
    args = paser.parse_args()

    gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
    tf.config.experimental.set_visible_devices(devices=gpus[int(args.gpu)], device_type='GPU')
    test_num, test_db = get_test_dataset(args.language, bs=int(args.bs))

    model=UNFI()
    model.load_weights("../../save_model/UNIF/"+args.language+"/UNIF.pth")

    test_mrr = []
    test_topk = []
    with tqdm(total=int(test_num + 1)) as pbar:
        for code,fun_name,code_desc,neg_code_desc in test_db:
            pbar.update(1)
            qurey_repersent,code_repersent=model.qurey([code,fun_name,code_desc,neg_code_desc])
            tmp=[tf.keras.losses.cosine_similarity([i], code_repersent, axis=1) for i in qurey_repersent]
            test_mrr.append(comput_mrr(tmp))
            k_tmp = []
            for k in range(10):
                score_k = comput_topk(tmp, k + 1)
                k_tmp.append(score_k)
            test_topk=k_tmp
    print("test_mrr:", np.mean(test_mrr))
    for k in range(10):
        print("test:@precison", k + 1, ":", test_topk[k])
if __name__ == '__main__':
    test()

'''
python_model
test_mrr: 0.6008036437219004
test:@precison 1 : 0.46
test:@precison 2 : 0.67
test:@precison 3 : 0.74
test:@precison 4 : 0.79
test:@precison 5 : 0.8
test:@precison 6 : 0.81
test:@precison 7 : 0.84
test:@precison 8 : 0.86
test:@precison 9 : 0.86
test:@precison 10 : 0.87
java
test_mrr: 0.5584852290423735
test:@precison 1 : 0.48
test:@precison 2 : 0.62
test:@precison 3 : 0.7
test:@precison 4 : 0.74
test:@precison 5 : 0.75
test:@precison 6 : 0.79
test:@precison 7 : 0.81
test:@precison 8 : 0.81
test:@precison 9 : 0.82
test:@precison 10 : 0.83
'''