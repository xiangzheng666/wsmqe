import numpy as np
from tensorflow import keras
import tensorflow as tf
import math


class AttCodeEncoder(keras.Model):

    def __init__(self):
        super(AttCodeEncoder, self).__init__()
        self.emb_size = 100
        self.hidden_size = 100
        self.embedding = keras.layers.Embedding(10000, 100)
        # self.word_weights = get_word_weights(vocab_size)
        self.attention = keras.layers.Dense(1)
        self.drop=keras.layers.Dropout(0.25)

    def call(self, inputs, training=None, mask=None):
        embedded = self.embedding(inputs)  # input: [batch_sz x seq_len x 1]  embedded: [batch_sz x seq_len x emb_sz]
        embedded = self.drop(embedded)  # [batch_size x seq_len x emb_size]
        inital_value = tf.math.exp(tf.squeeze(self.attention(embedded),axis=2))
        attention_weight = tf.divide(inital_value, tf.reduce_sum(inital_value, 1, True))
        attention_weight = tf.expand_dims(attention_weight,-1)
        output = tf.squeeze(tf.matmul(tf.transpose(embedded,[0,2, 1]), attention_weight),axis=2)
        return output


class SeqEncoder(keras.Model):
    def __init__(self):
        super(SeqEncoder, self).__init__()
        self.emb_size = 100
        self.hidden_size = 100
        self.n_layers = 1
        self.embedding = keras.layers.Embedding(10000, 100)
        self.drop = keras.layers.Dropout(0.25)

    def call(self, inputs, training=None, mask=None):
        batch_size, seq_len = inputs.shape
        inputs = self.embedding(inputs)  # input: [batch_sz x seq_len]  embedded: [batch_sz x seq_len x emb_sz]
        inputs = self.drop(inputs)
        encoding = tf.reduce_sum(inputs, 1, True) / seq_len
        encoding = tf.squeeze(encoding,axis=1)

        return encoding


def get_word_weights(vocab_size, padding_idx=0):
    '''contruct a word weighting table '''

    def cal_weight(word_idx):
        return 1 - math.exp(-word_idx)

    weight_table = np.array([cal_weight(w) for w in range(vocab_size)])
    if padding_idx is not None:
        weight_table[padding_idx] = 0.  # zero vector for padding dimension
    return tf.convert_to_tensor(weight_table,dtype=tf.float32)

class UNFI(keras.Model):
    def __init__(self):
        super(UNFI, self).__init__()

        self.code_present=AttCodeEncoder()
        self.desc_present=SeqEncoder()

    def call(self, inputs, training=None, mask=None):
        code, fun_name, code_desc, neg_code_desc = inputs
        code_vect=self.code_present(code)
        desc_vect=self.desc_present(code_desc)
        neg_code_desc_vect = self.desc_present(neg_code_desc)

        return neg_code_desc_vect,code_vect,desc_vect
    def repersent(self,inputs):
        code, fun_name, code_desc = inputs
        code_vect = self.code_present(code)
        desc_vect = self.desc_present(code_desc)
        return code_vect,desc_vect

    def qurey(self,inputs):
        code, fun_name, code_desc, neg_code_desc = inputs
        code_vect = self.code_present(code)
        desc_vect = self.desc_present(code_desc)

        return code_vect, desc_vect

    def eval(self,inputs,more=None):
        code, fun_name, code_desc = inputs
        code_vect = self.code_present(code)
        desc_vect = self.desc_present(code_desc)
        if more:
            sortednum, simirity, source=more
            for i in range(sortednum.shape[1]):
                tmp = self.desc_present(tf.concat([np.expand_dims(source[int(j),:], axis=0) for j in sortednum[:, i]], axis=0))
                desc_vect = desc_vect + tmp * tf.expand_dims(np.clip(-simirity[:, i], 0.1, 0.4), axis=1)

        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in desc_vect]

    def evalGPT(self,inputs,b=0):

        code, func, qurey, qurey_o=inputs
        code_vect = self.code_present(code)
        desc_vect = [self.desc_present(i) for i in qurey]
        desc_o_vect = self.desc_present(qurey_o)

        scorelist = [[tf.clip_by_value(-tf.keras.losses.cosine_similarity(i, j),0,1).numpy() for i, j in zip(desc, desc_o_vect)] for desc in desc_vect]
        scorelist.append([1 for _ in range(len(scorelist[0]))])

        scorelist=tf.cast(tf.nn.softmax(np.array(scorelist),axis=0),dtype=tf.float32)

        for i in range(len(scorelist)-1):
            desc_o_vect=desc_o_vect+tf.expand_dims(scorelist[i],axis=-1)*desc_vect[i]

        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in desc_o_vect]
        
    def eval_more(self,inputs,b=0):

        code, func, qurey, qurey_o=inputs
        code_vect = self.code_present(code)
        desc_vect = [self.desc_present(i) for i in qurey]
        desc_o_vect = self.desc_present(qurey_o)

        print(desc_o_vect.shape)
        new_desc=tf.reduce_max(desc_vect,axis=0)
        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in new_desc]


    def setmlp(self,mlp):
        self.mlp=mlp

    def evalmlp(self,inputs,b=0):
        code, func, qurey, qurey_o=inputs
        code_vect = self.code_present(code)
        desc_vect=self.mlp.getvect([qurey_o,qurey[0],qurey[1],qurey[2]])
        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in desc_vect]