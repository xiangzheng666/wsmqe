from tensorflow import keras
from tensorflow_core.python.keras.layers import Lambda
from tensorflow.keras import backend as K
import tensorflow as tf
import numpy as np

class deepcs(keras.Model):
    def __init__(self):
        super(deepcs, self).__init__()

        self.maxpool = Lambda(lambda x: K.max(x, axis=1, keepdims=False), output_shape=lambda x: (x[0], x[2]),
                              name='maxpool_methname')

        # ---------------funcname_repersent-----------------------
        self.funcname_embeding = keras.layers.Embedding(10000, 100)
        self.funcname_embeding_dropout= keras.layers.Dropout(0.25)
        self.funcname_lstm_1 = keras.layers.LSTM(100, return_sequences=True, recurrent_dropout=0.2)
        self.funcname_lstm_2 = keras.layers.LSTM(100, return_sequences=True, recurrent_dropout=0.2)
        self.funcname_lstm_embeding_dropout = keras.layers.Dropout(0.25)

        # ---------------code_repersent-----------------------
        self.code_embeding = keras.layers.Embedding(10000, 100)
        self.code_embeding_dropout = keras.layers.Dropout(0.25)

        # ---------------code_desc_repersent-----------------------
        self.code_desc_embeding = keras.layers.Embedding(10000, 100)
        self.code_desc_embeding_dropout = keras.layers.Dropout(0.25)
        self.code_desc_lstm_1 = keras.layers.LSTM(100, return_sequences=True, recurrent_dropout=0.2)
        self.code_desc_lstm_2 = keras.layers.LSTM(100, return_sequences=True, recurrent_dropout=0.2)
        self.code_desc_lstm_embeding_dropout = keras.layers.Dropout(0.25)

        #---------------CONCATE--------------
        self.dense=keras.layers.Dense(2*100,activation="tanh")

    def funcname_repersent(self, funcname):
        funcname=self.funcname_embeding_dropout(self.funcname_embeding(funcname))
        l1 = self.maxpool(self.funcname_lstm_embeding_dropout(self.funcname_lstm_1(funcname)))
        l2 = self.maxpool(self.funcname_lstm_embeding_dropout(self.funcname_lstm_2(funcname)))
        funcname=keras.layers.concatenate([l1,l2],axis=1)
        return keras.layers.Activation('tanh')(funcname)

    def code_repersent(self, code):
        code=self.code_embeding_dropout(self.code_embeding(code))
        maxpool = self.maxpool(code)
        return keras.layers.Activation('tanh')(maxpool)

    def code_desc_repersent(self, code_desc):
        code_desc=self.code_desc_embeding_dropout(self.code_desc_embeding(code_desc))
        l1 = self.maxpool(self.code_desc_lstm_embeding_dropout(self.code_desc_lstm_1(code_desc)))
        l2 = self.maxpool(self.code_desc_lstm_embeding_dropout(self.code_desc_lstm_2(code_desc)))
        code_desc=keras.layers.concatenate([l1,l2],axis=1)
        return keras.layers.Activation('tanh')(code_desc)

    def concate(self,code,fun_name):
        return self.dense(keras.layers.concatenate([code,fun_name], axis=1))

    def call(self, inputs, training=None, mask=None):
        code, fun_name, code_desc, neg_code_desc = inputs

        neg_code_desc_repersent=self.code_desc_repersent(neg_code_desc)

        code = self.code_repersent(code)
        fun_name = self.funcname_repersent(fun_name)
        code_repersent=self.concate(code,fun_name)

        code_desc_repersent = self.code_desc_repersent(code_desc)

        return neg_code_desc_repersent,code_repersent,code_desc_repersent
    def repersent(self,inputs):
        code, fun_name, code_desc = inputs
        code = self.code_repersent(code)
        fun_name = self.funcname_repersent(fun_name)
        code_repersent = self.concate(code, fun_name)
        qurey_repersent = self.code_desc_repersent(code_desc)
        return code_repersent,qurey_repersent

    def qurey(self, inputs):
        code, fun_name, code_desc, neg_code_desc = inputs

        code = self.code_repersent(code)
        fun_name = self.funcname_repersent(fun_name)
        code_repersent = self.concate(code, fun_name)

        qurey_repersent = self.code_desc_repersent(code_desc)
        return qurey_repersent, code_repersent

    def eval(self,inputs,more=None):
        code, fun_name, code_desc = inputs
        code = self.code_repersent(code)

        fun_name = self.funcname_repersent(fun_name)
        code_repersent = self.concate(code, fun_name)

        qurey_repersent = self.code_desc_repersent(code_desc)


        return [tf.keras.losses.cosine_similarity([i], code_repersent, axis=1) for i in qurey_repersent]

    def evalGPT(self,inputs,b):
        code, fun_name, code_desc, qurey_o=inputs
        code = self.code_repersent(code)
        fun_name = self.funcname_repersent(fun_name)
        code_vect = self.concate(code, fun_name)
        desc_vect = [self.code_desc_repersent(i) for i in code_desc]
        desc_o_vect = self.code_desc_repersent(qurey_o)

        scorelist = [[tf.clip_by_value(-tf.keras.losses.cosine_similarity(i, j), 0, 1).numpy() for i, j in
                      zip(desc, desc_o_vect)] for desc in desc_vect]
        scorelist.append([1 for _ in range(len(scorelist[0]))])

        scorelist = tf.cast(tf.nn.softmax(np.array(scorelist), axis=0), dtype=tf.float32)

        for i in range(len(scorelist) - 1):
            desc_o_vect = desc_o_vect + tf.expand_dims(scorelist[i], axis=-1) * desc_vect[i]
        return [tf.keras.losses.cosine_similarity([i], code_vect, axis=1) for i in desc_o_vect]