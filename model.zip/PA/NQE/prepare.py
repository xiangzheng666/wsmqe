import tensorflow as tf
from tqdm import tqdm
from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
import re

tokenizer = AutoTokenizer.from_pretrained("roberta-base",do_lower_case =True)
def tokenit(txt):
    return [re.sub("Ġ","",i).lower() for i in tokenizer.tokenize(txt)]

lan="java"

with open("../../../dataset/train_data/"+lan+"/docstring.txt",'r') as f:
    data = f.read().split('\n')[:-1]

vocab=[]
with open("data/"+lan+"/src_train.txt","w") as f:
    for i in tqdm(data[:-2000]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')

with open("data/"+lan+"/src_valid.txt","w") as f:
    for i in tqdm(data[-2000:-1000]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')

with open("data/"+lan+"/src_test.txt","w") as f:
    for i in tqdm(data[-1000:-1]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')

with open("data/"+lan+"/src_vocab.txt","w") as f:
    f.write("\n".join(list(set(vocab))))




with open("../../../dataset/train_data/"+lan+"/func.txt",'r') as f:
    data = f.read().split('\n')[:-1]

vocab=[]
with open("data/"+lan+"/tgt_train.txt","w") as f:
    for i in tqdm(data[:-2000]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')

with open("data/"+lan+"/tgt_valid.txt","w") as f:
    for i in tqdm(data[-2000:-1000]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')

with open("data/"+lan+"/tgt_test.txt","w") as f:
    for i in tqdm(data[-1000:-1]):
        words=tokenit(i)
        vocab.extend(words)
        f.write(" ".join(words)+'\n')


with open("data/"+lan+"/tgt_vocab.txt","w") as f:
    f.write("\n".join(list(set(vocab))))