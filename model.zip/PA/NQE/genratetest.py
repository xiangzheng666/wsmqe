import tensorflow as tf
import typing 
import os 

gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
tf.config.experimental.set_visible_devices(devices=gpus[1], device_type='GPU')

language="python"

CONST = {
    'PAD': 0,
    'START': 1,
    'END': 2,
    'UNK': 3,
}
MAX_LENGTH = 40

class Encoder(tf.keras.Model):

    def __init__(self, vocab_size: int, embedding_dim: int, enc_units: int) -> None:
        super(Encoder, self).__init__()
        self.enc_units = enc_units
        self.embedding = tf.keras.layers.Embedding(vocab_size, embedding_dim)
        self.gru = tf.keras.layers.GRU(self.enc_units, return_sequences=True, return_state=True)

    def call(self, x: tf.Tensor) -> typing.Tuple[tf.Tensor, tf.Tensor]:
        x = self.embedding(x)
        output, state = self.gru(x)
        return output, state


class BahdanauAttention(tf.keras.Model):

    def __init__(self, units: int) -> None:
        super(BahdanauAttention, self).__init__()
        self.W1 = tf.keras.layers.Dense(units)
        self.W2 = tf.keras.layers.Dense(units)
        self.V = tf.keras.layers.Dense(1)

    def call(self, query: tf.Tensor, values: tf.Tensor) -> typing.Tuple[tf.Tensor, tf.Tensor]:
        # hidden shape == (batch_size, hidden size)
        # hidden_with_time_axis shape == (batch_size, 1, hidden size)
        # we are doing this to perform addition to calculate the score
        hidden_with_time_axis = tf.expand_dims(query, 1)

        # score shape == (batch_size, max_length, 1)
        # we get 1 at the last axis because we are applying score to self.V
        # the shape of the tensor before applying self.V is (batch_size, max_length, units)
        score = self.V(tf.nn.tanh(self.W1(values) + self.W2(hidden_with_time_axis)))

        # attention_weights shape == (batch_size, max_length, 1)
        attention_weights = tf.nn.softmax(score, axis=1)

        # context_vector shape after sum == (batch_size, hidden_size)
        context_vector = attention_weights * values
        context_vector = tf.reduce_sum(context_vector, axis=1)

        return context_vector, attention_weights


class Decoder(tf.keras.Model):

    def __init__(self, vocab_size: int, embedding_dim: int, dec_units: int):
        super(Decoder, self).__init__()
        self.dec_units = dec_units
        self.embedding = tf.keras.layers.Embedding(vocab_size, embedding_dim)
        self.gru = tf.keras.layers.GRU(self.dec_units, return_sequences=True, return_state=True)
        self.fc = tf.keras.layers.Dense(vocab_size)
        self.attention = BahdanauAttention(self.dec_units)

    def call(self, x: tf.Tensor, hidden: tf.Tensor, enc_output: tf.Tensor) \
            -> typing.Tuple[tf.Tensor, tf.Tensor, tf.Tensor]:
        # enc_output shape == (batch_size, max_length, hidden_size)
        context_vector, attention_weights = self.attention(hidden, enc_output)

        # x shape after passing through embedding == (batch_size, 1, embedding_dim)
        x = self.embedding(x)

        # x shape after concatenation == (batch_size, 1, embedding_dim + hidden_size)
        x = tf.concat([tf.expand_dims(context_vector, 1), x], axis=-1)

        # passing the concatenated vector to the GRU
        output, state = self.gru(x)

        # output shape == (batch_size * 1, hidden_size)
        output = tf.reshape(output, (-1, output.shape[2]))

        # output shape == (batch_size, vocab)
        x = self.fc(output)

        return x, state, attention_weights


def get_index_table_from_file(path: str) -> tf.lookup.StaticHashTable:
    table = tf.lookup.StaticHashTable(
        tf.lookup.TextFileInitializer(
            path,
            tf.string,
            tf.lookup.TextFileIndex.WHOLE_LINE,
            tf.int64,
            tf.lookup.TextFileIndex.LINE_NUMBER
        ),
        CONST['UNK'] - len(CONST)
    )
    return table


def get_dataset(src_path: str, table: tf.lookup.StaticHashTable) -> tf.data.Dataset:

    def to_ids(text):
        tokenized = tf.strings.split(tf.reshape(text, [1]), sep=' ')
        ids = table.lookup(tokenized.values) + len(CONST)
        return ids

    def add_start_end_tokens(tokens):
        ids = tf.concat([[CONST['START']], tf.cast(tokens, tf.int32), [CONST['END']]], axis=0)
        return ids

    dataset = tf.data.TextLineDataset(src_path)
    dataset = dataset.map(to_ids)
    dataset = dataset.map(add_start_end_tokens)
    return dataset


def filter_instance_by_max_length(src: tf.Tensor, tgt: tf.Tensor) -> tf.Tensor:
    return tf.logical_and(tf.size(src) <= MAX_LENGTH, tf.size(tgt) <= MAX_LENGTH)


src_table = get_index_table_from_file(os.path.join("data/"+language, 'src_vocab.txt'))
tgt_table = get_index_table_from_file(os.path.join("data/"+language, 'tgt_vocab.txt'))

key_tensor = tgt_table.export()[1].numpy()
value_tensor = tgt_table.export()[0].numpy()
value_tensor = tf.constant(value_tensor, dtype=tf.string)
key_tensor = tf.constant(key_tensor, dtype=tf.int64)
reverse_table = tf.lookup.StaticHashTable(
    tf.lookup.KeyValueTensorInitializer(key_tensor,value_tensor),
    default_value="UNK"
)

optimizer = tf.keras.optimizers.Adam()
encoder = Encoder(
    src_table.size().numpy() + len(CONST),
    256,
    1024
)
decoder = Decoder(
    tgt_table.size().numpy() + len(CONST),
    256,
    1024
)


checkpoint = tf.train.Checkpoint(optimizer=optimizer, encoder=encoder, decoder=decoder)
checkpoint.restore(tf.train.latest_checkpoint("./model/"+language+"/checkpoints"))

def predict(src,encoder=encoder, decoder=decoder, start_token=1, end_token=2, max_len=10):
    enc_output, enc_hidden = encoder(src)
    dec_hidden = enc_hidden
    dec_input = tf.expand_dims([start_token], 0)
    result = []
    for i in range(max_len):
        predictions, dec_hidden, _= decoder(dec_input, dec_hidden, enc_output)
        predicted_id = tf.argmax(predictions[0]).numpy()
        if predicted_id == end_token:
            return result
        result.append(predicted_id)
        dec_input = tf.expand_dims([predicted_id], 0)
    return result

def to_ids(text):
    tokenized = tf.strings.split(tf.reshape(text, [1]), sep=' ')
    ids = src_table.lookup(tokenized.values) + len(CONST)
    return ids

def add_start_end_tokens(tokens):
    ids = tf.concat([[CONST['START']], tf.cast(tokens, tf.int32), [CONST['END']]], axis=0)
    return ids

text="remove repeated elements from Array List"
ta="check if queue is empty"
def genrate(text):
    ids = to_ids(text)
    ids = add_start_end_tokens(ids)
    resultids = [i-len(CONST) for i in predict(tf.expand_dims(ids,axis=0))]
    word_tensor = reverse_table.lookup(tf.constant(resultids,dtype=tf.int64)).numpy()

    return text+" "+" ".join([str(i,encoding='utf-8') for i in word_tensor])

print(genrate(text))