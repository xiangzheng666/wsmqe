import numpy as np
from tqdm import tqdm

import tensorflow as tf
from transformers import RobertaTokenizer
import re

language="python"

tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
if language=="python":
    name_list=["CSN-V","DEV","webqurey","transfer"]
else:
    name_list = ["CosBeach", "CSN-V", "NCSED","transfer"]

with open("toji/"+language+"_pattern.txt", "r+") as f:
    pattern=f.read().split("\n")
with open("toji/"+language+"_rules.txt", "r+") as f:
    rules=f.read().split("\n")

def isnn(word):
    if nltk.pos_tag([word])[0][1] in ['NN','NNP','NNS','NNPS']:
        return True
    else:
        return False
        
pattern=[[i.split(" ")[0].split("_"),i.split(" ")[1]] for i in pattern if len(i.split(" ")[0].split("_"))>1]
pattern=sorted(pattern,key=lambda x:int(x[1]),reverse=True)
pattern=[i[0] for i in pattern]

def util(text):
    return text


def fp_expand():
    path=["../../../dataset/eval_dataset/"+language+"/"+str(i)+"/qurey_filter.txt" for i in name_list]
    for p,n in zip(path,name_list):
        with open(p,"r+",encoding="utf-8") as f:
            data=f.read().split('\n')
        qurey_wordnet="\n".join([util(i) for i in data])

        with open(language+"/"+n+"_fp_qurey.txt","w+",encoding="utf-8") as f:
            f.write(qurey_wordnet)



docstring_tokens_id2word = {}
docstring_tokens_word2id = {}
with open("../../../dataset/train_data/"+language+"/docstring_tokens_vocab.txt", "r+", encoding='utf-8') as f:
    for index, i in enumerate(f.read().split("\n")):
        docstring_tokens_id2word[index] = i
        docstring_tokens_word2id[i] = index
        
def tokenit(txt):
    return [re.sub("Ġ","",i).lower() for i in tokenizer.tokenize(txt)]
fp_expand()
for n in name_list:
    with open(language+"/"+n+"_fp_qurey.txt","r+",encoding="utf-8") as f:
        data=f.read().split('\n')
    num=[]
    num1=[]
    for i in tqdm(data):
        tmp=[]
        tmp1=[]
        orign,wordnet=i.split("==========")
        for j in tokenit(orign):
            if j in docstring_tokens_word2id.keys():
                tmp.append(docstring_tokens_word2id[j])
            else:
                tmp.append(1)
        for j in tokenit(orign):
            if j in docstring_tokens_word2id.keys():
                tmp1.append(docstring_tokens_word2id[j])
            else:
                tmp1.append(1)
        num.append(tmp)
        num1.append(tmp1)
    qurey_wordnet = tf.keras.preprocessing.sequence.pad_sequences(num, maxlen=60, padding='post',
                                                                  truncating='post', value=0)
    qurey_wordnet1 = tf.keras.preprocessing.sequence.pad_sequences(num1, maxlen=60, padding='post',
                                                                  truncating='post', value=0)
    np.save(language+"/"+n+"_fp_qurey", qurey_wordnet)
    np.save(language + "/" + n + "_fp_qurey_1", qurey_wordnet)
