import tensorflow as tf
from transformers import RobertaTokenizer
import re
from tqdm import tqdm
import numpy as np

language="java"

tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
def tokenit(txt):
    return [re.sub("Ġ","",i).lower() for i in tokenizer.tokenize(txt)]

if language=="python":
    name_list=["CSN-V","DEV","webqurey","transfer"]
else:
    name_list = ["CosBeach", "CSN-V", "NCSED","transfer"]


docstring_tokens_id2word = {}
docstring_tokens_word2id = {}
with open("../../../dataset/train_data/"+language+"/docstring_tokens_vocab.txt", "r+", encoding='utf-8') as f:
    for index, i in enumerate(f.read().split("\n")):
        docstring_tokens_id2word[index] = i
        docstring_tokens_word2id[i] = index

for n in name_list:
    with open(language+"/"+n+".txt","r+",encoding="utf-8") as f:
        data=f.read().split('\n')
    num=[]
    for i in tqdm(data):
        tmp=[]
        for j in tokenit(i):
            if j in docstring_tokens_word2id.keys():
                tmp.append(docstring_tokens_word2id[j])
            else:
                tmp.append(1)
        num.append(tmp)
    qurey_QECK = tf.keras.preprocessing.sequence.pad_sequences(num, maxlen=60, padding='post',
                                                                  truncating='post', value=0)

    np.save(language+"/"+n+"_QECK_qurey", qurey_QECK)
