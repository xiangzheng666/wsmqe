import numpy as np
import tensorflow as tf
from GPT import descGPT

def sample_from(logits):
    logits, indices = tf.math.top_k(logits, k=5, sorted=True)
    indices = np.asarray(indices).astype("int32")
    preds = tf.keras.activations.softmax(tf.expand_dims(logits, 0))[0]
    preds = np.asarray(preds).astype("float32")
    return np.random.choice(indices, p=preds)

def generate_text(model, start_text, id2word,word2id,maxlen=10):
    out=[]
    for i in range(5):
        start_tokens = [word2id.get(_, 1) for _ in start_text.split(" ")]
        num_tokens_generated = 0
        tokens_generated = []
        while num_tokens_generated <= maxlen:
            pad_len = maxlen - len(start_tokens)
            sample_index = len(start_tokens) - 1
            if pad_len < 0:
                x = start_tokens[:maxlen]
                sample_index = maxlen - 1
            elif pad_len > 0:
                x = start_tokens + [0] * pad_len
            else:
                x = start_tokens
            x = np.array([x])
            y = model(x)
            sample_token = sample_from(y[0][sample_index])
            tokens_generated.append(sample_token)
            start_tokens.append(sample_token)
            num_tokens_generated = len(tokens_generated)
        out.append(
            " ".join([id2word[_] for _ in start_tokens + tokens_generated])
        )
        print(out)
    return out


# Example usage:
start_text = "convert int to str"
model = descGPT()
model.load_weights("gptmodel/gptourall/last_model")
with open("../../../dataset/GPT_data/vocab10000.json", "r+", encoding='utf-8') as f:
    word2id = eval(f.read())
    id2word={v:k for k,v in word2id.items()}

generate_text(model, start_text, id2word,word2id)
