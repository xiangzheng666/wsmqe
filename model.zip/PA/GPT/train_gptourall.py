import numpy as np
from tqdm.asyncio import tqdm
import tensorflow as tf
from GPT import descGPT

# Create a MirroredStrategy object
strategy = tf.distribute.MirroredStrategy()

@tf.function
def parse_example(example_proto):
    """
    Parses an example proto and returns tensors for each feature.
    """
    feature_description = {
        'x': tf.io.FixedLenFeature([], tf.string),
        'x_mask': tf.io.FixedLenFeature([], tf.string),
        'y': tf.io.FixedLenFeature([], tf.string),
    }
    parsed_example = tf.io.parse_single_example(example_proto, feature_description)
    parsed_example['x'] = tf.io.decode_raw(parsed_example['x'], out_type=tf.int64)
    parsed_example['x_mask'] = tf.io.decode_raw(parsed_example['x_mask'], out_type=tf.int64)
    parsed_example['y'] = tf.io.decode_raw(parsed_example['y'], out_type=tf.int64)

    return parsed_example['x'], parsed_example['x_mask'], parsed_example['y']
    
@tf.function
def sample_from(logits):
    logits, indices = tf.math.top_k(logits, k=10, sorted=True)
    indices = np.asarray(indices).astype("int32")
    preds = tf.keras.activations.softmax(tf.expand_dims(logits, 0))[0]
    preds = np.asarray(preds).astype("float32")
    return np.random.choice(indices, p=preds)
        
@tf.function
def call_back(model,start_tokens,id2word,word2id,maxlen=10):
    start_tokens = [word2id.get(_, 1) for _ in start_tokens.split(" ")]
    num_tokens_generated = 0
    tokens_generated = []
    while num_tokens_generated <= maxlen:
        pad_len = maxlen - len(start_tokens)
        sample_index = len(start_tokens) - 1
        if pad_len < 0:
            x = start_tokens[:maxlen]
            sample_index = maxlen - 1
        elif pad_len > 0:
            x = start_tokens + [0] * pad_len
        else:
            x = start_tokens
        x = np.array([x])
        y = model(x)
        print(y)
        sample_token = sample_from(y[0][sample_index])
        tokens_generated.append(sample_token)
        start_tokens.append(sample_token)
        num_tokens_generated = len(tokens_generated)
    txt = " ".join(
        [id2word[_] for _ in start_tokens + tokens_generated]
    )
    print(f"generated text:\n{txt}\n")

batch_size = 1500
epochs = 100

batch_size = batch_size * strategy.num_replicas_in_sync

# Distribute the model across the available GPUs
with strategy.scope():
    with open("../../../dataset/GPT_data/vocab10000.json", "r+", encoding='utf-8') as f:
        word2id = eval(f.read())
        id2word={v:k for k,v in word2id.items()}
    model = descGPT()
    try:
        model.load_weights("gptmodel/gptourall/best_model")
        print("load save_model sucess")
    except:
        pass

train = tf.data.TFRecordDataset('../../../dataset/GPT_data/train.tfrecord').map(parse_example).batch(batch_size,drop_remainder=True)
test = tf.data.TFRecordDataset('../../../dataset/GPT_data/test.tfrecord').map(parse_example).batch(100* strategy.num_replicas_in_sync,drop_remainder=True)

# Adjust the batch size to the number of GPUs
global_batch_size = batch_size * strategy.num_replicas_in_sync

# Create distributed datasets
train_dist = strategy.experimental_distribute_dataset(train)
test_dist = strategy.experimental_distribute_dataset(test)

loss_fn = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True,reduction=tf.keras.losses.Reduction.NONE)
acc = tf.keras.metrics.sparse_categorical_accuracy
optimizer = tf.keras.optimizers.Adamax()

@tf.function()
def train_step(inputs):
    batch_x, batch_x_mask, batch_y = inputs
    with tf.GradientTape() as tape:
        pre= model(batch_x)
        batch_loss = loss_fn(batch_y, pre)
        batch_acc = acc(batch_y, pre)

    grads = tape.gradient(batch_loss, model.trainable_variables)
    optimizer.apply_gradients(zip(grads, model.trainable_variables))
    
    return batch_loss, batch_acc

@tf.function()
def test_step(inputs):
    batch_x, batch_x_mask, batch_y = inputs

    pre = model(batch_x)
    batch_loss = loss_fn(batch_y, pre)
    batch_acc = acc(batch_y, pre)

    return batch_loss, batch_acc


score = 0
with strategy.scope():
    for epoch in range(epochs):
        
        train_loss = tf.keras.metrics.Mean()
        train_acc = tf.keras.metrics.Mean()
        test_loss = tf.keras.metrics.Mean()
        test_acc = tf.keras.metrics.Mean()

        # Train loop
        with tqdm(total=int(25621454 / batch_size)) as pbar:
            for batch in train_dist:
                pbar.update(1)
                batch_loss, batch_acc = strategy.experimental_run_v2(train_step, args=(batch,))
                batch_loss = strategy.reduce(tf.distribute.ReduceOp.SUM, batch_loss, axis=None)
                batch_acc = strategy.reduce(tf.distribute.ReduceOp.MEAN, batch_acc, axis=None)
                train_loss(batch_loss)
                train_acc(batch_acc)

        # Test loop
        with tqdm(total=int(1000 / batch_size)) as pbar:
            for batch in test_dist:
                pbar.update(1)
                batch_loss, batch_acc = strategy.experimental_run_v2(test_step, args=(batch,))
                batch_loss = strategy.reduce(tf.distribute.ReduceOp.SUM, batch_loss, axis=None)
                batch_acc = strategy.reduce(tf.distribute.ReduceOp.MEAN, batch_acc, axis=None)
                test_loss(batch_loss)
                test_acc(batch_acc)

        # Print progress
        print(
            f'Epoch {epoch + 1}, Train Loss: {train_loss.result()}, Train Accuracy: {train_acc.result()}, Test Loss: {test_loss.result()}, Test Accuracy: {test_acc.result()}')
        model.save_weights('gptmodel/gptourall/last_model')
        # Save model if it's the best so far
        if test_acc.result() > score:
            model.save_weights('gptmodel/gptourall/best_model')
            score = test_acc.result()
