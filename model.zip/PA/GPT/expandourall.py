import os
import re
import warnings

import numpy as np

warnings.filterwarnings("ignore")

import tensorflow as tf
from tqdm import tqdm
from transformers import TFGPT2LMHeadModel, GPT2Tokenizer,RobertaTokenizer

gpus = tf.config.experimental.list_physical_devices('GPU')
for gpu in gpus:
    tf.config.experimental.set_memory_growth(gpu, True)

gpus = tf.config.experimental.list_physical_devices(device_type='GPU')
tf.config.experimental.set_visible_devices(devices=gpus[1], device_type='GPU')

from GPT import descGPT
model = descGPT()
model.load_weights("gptmodel/gptourall/last_model")
with open("../../../dataset/GPT_data/vocab10000.json", "r+", encoding='utf-8') as f:
    word2id = eval(f.read())
    id2word={v:k for k,v in word2id.items()}


def sample_from(logits):
    logits, indices = tf.math.top_k(logits, k=5, sorted=True)
    indices = np.asarray(indices).astype("int32")
    preds = tf.keras.activations.softmax(tf.expand_dims(logits, 0))[0]
    preds = np.asarray(preds).astype("float32")
    return np.random.choice(indices, p=preds)

def generate_text(model, start_text, id2word=id2word,word2id=word2id,maxlen=20):
    out=[]
    for i in range(5):
        start_tokens = [word2id.get(_, 1) for _ in tokenit(start_text)]
        num_tokens_generated = 0
        tokens_generated = []
        while num_tokens_generated <= maxlen:
            pad_len = maxlen - len(start_tokens)
            sample_index = len(start_tokens) - 1
            if pad_len < 0:
                x = start_tokens[:maxlen]
                sample_index = maxlen - 1
            elif pad_len > 0:
                x = start_tokens + [0] * pad_len
            else:
                x = start_tokens
            x = np.array([x])
            y = model(x)
            sample_token = sample_from(y[0][sample_index])
            tokens_generated.append(sample_token)
            start_tokens.append(sample_token)
            num_tokens_generated = len(tokens_generated)
        out.append(
            " ".join([id2word[_] for _ in start_tokens + tokens_generated])
        )
    return out


l='java'

if l=="python":
    name_list=["CSN-V","DEV","webqurey","transfer"]
else:
    name_list = ["CosBeach", "CSN-V", "NCSED","transfer"]
num=10
def to_txt():
    for n in name_list:
        with open("../../../dataset/eval_dataset/"+l+"/"+n+"/qurey.txt","r+",encoding="utf-8") as f:
            data=f.read().split('\n')[:100]
        with open("gpt2ourall/"+l + "/"+n+"_GPT_qurey.txt", "w+", encoding="utf-8") as f:
            with tqdm(total=len(data)) as pbar:
                for i in data:
                    pbar.update(1)
                    
                    text ="==========".join(generate_text(model,i))
                    f.write(re.sub("\n","",text)+"\n")
                    f.flush()

tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
def tokenit(txt):
    txt=txt.lower()
    return [re.sub("Ġ|Ċ","",i) for i in tokenizer.tokenize(txt)]

def to_np():
    with open("../../../dataset/train_data/"+l+"/docstring_tokens_vocab.txt", "r+", encoding="utf-8") as f:
        vocab = f.read().split("\n")
        vocab_tokern2id = {vocab[i]: i for i in range(len(vocab))}
    for n in name_list:
        for index in range(10):
            with open("gpt2ourall/"+l + "/"+n+"_GPT_qurey.txt", "r+", encoding="utf-8") as f:
                data=[]
                for i in f.read().split('\n')[:-1]:
                    tmp=i.split("==========")
                    if (len(tmp)<=index):
                        data.append(tmp[0])
                        break
                    data.append(tmp[index])
            data1=[]
            for txt in tqdm(data):
                data1.append([vocab_tokern2id.get(i,1) for i in tokenit(txt)])

            data = tf.keras.preprocessing.sequence.pad_sequences(data1,
                                                                 maxlen=60, padding='post',
                                                                 truncating='post', value=0)
            np.save(os.path.join(os.path.join(os.path.join("gpt2ourall/",l), n+'_GPT_qurey_'+str(index))), data)
to_txt()
to_np()