import string,nltk
from nltk.corpus import wordnet
import re
nltk.download('wordnet')
stop_words = {'between', "that'll", 'hadn', "you'd", 'do', 'against', 'such', "isn't", 'been', "couldn't", 'shouldn', 'this', 'as', 'if', 'was', 'until', "aren't", 'with', 'its', 'here', 'hasn', 'y', 'them', 'few', 'out', 'm', 'yours', 'down', 'any', 'haven', 'him', 'didn', 'i', 'ours', 'hers', 'it', 'who', 'won', 'what', 'then', 's', 'should', 'myself', 'are', 'is', 'in', 'nor', 'he', 'to', 't', 'by', 're', 'had', 'themselves', 'isn', 'too', 'each', 'does', 'their', 'through', 'whom', 'doesn', 'herself', 'or', 'you', 'have', 'we', 'about', 'than', 'my', 'again', 'other', "you've", "wasn't", 'himself', 'be', 'the', 'all', 'doing', 'how', "you're", 'above', "you'll", "hasn't", 'mightn', "haven't", 'these', 'yourself', 'couldn', 'she', 'can', 'did', 'aren', 'very', "mustn't", 'more', 'so', 'your', 'a', "hadn't", 'further', 'having', 'when', 'most', 'but', 'there', 'once', 'd', 'her', 'same', "needn't", 'being', 'an', 'itself', 'will', 'and', 'no', "mightn't", 'those', "won't", "wouldn't", 'own', 'at', 'our', 'before', 'both', 'has', 'for', 'only', 'am', "shouldn't", 'not', 'don', "weren't", "don't", 'o', 'after', 'that', 'theirs', 'during', "shan't", 'ain', 'below', 'off', 'where', 'll', 'because', 'ma', 'me', "it's", 'shan', 'from', 'some', 'just', 'on', 've', 'why', 'over', 'up', "didn't", 'needn', 'of', 'ourselves', 'weren', 'they', 'mustn', 'wasn', 'while', 'under', "should've", "doesn't", "she's", 'which', 'wouldn', 'now', 'were', 'his', 'yourselves', 'into'}


def util(line):
    # if not line:
    #     break

    _line = line
    line = line.replace('\n', '')
    line = line.split(" ", 1)
    new_line = line[0]
    # line = ["i", "have", "a", "pen"]

    line[1] = line[1].lower()
    line[1] = line[1].translate(str.maketrans('', '',string.punctuation))
    word_tokens = line[1].split(" ")
    print(word_tokens)
    filtered_sentence = [w for w in word_tokens if not w in stop_words]
    synonyms = []
    for x in filtered_sentence:
        m=0
        for syn in wordnet.synsets(x):
            count = 0
            for l in syn.lemmas():
                if count < 1 and m < 3:
                    if l.name() not in synonyms:
                        tmp=l.name()
                        synonyms.extend(str(tmp).split("_"))
                        count += 1
                        m +=1

    synonyms_string = ' '.join(synonyms)
    # new_line=" ".join([str(new_line),synonyms_string])
    synonyms = []
    return _line+"=========="+synonyms_string

    #     fout.write(new_line)
    #     fout.write('\n')
    # f.close()
    # fout.close()
if __name__ == '__main__':
        print(util("how do i plot bars using pandas"))