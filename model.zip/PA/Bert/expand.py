import os
import re
import warnings

import numpy as np

warnings.filterwarnings("ignore")

import tensorflow as tf
from tqdm import tqdm
from transformers import BertTokenizer, TFBertForMaskedLM,RobertaTokenizer


gpus = tf.config.list_physical_devices('GPU')
tf.config.set_visible_devices(gpus[1], 'GPU')


model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = TFBertForMaskedLM.from_pretrained("bertmodel/last_model")

l='python'
def getrandom_num():
    probabilities = [1, 0.6, 0.5, 0.4]
    weights = 1 / np.array(probabilities)
    weights = weights / np.sum(weights)
    numbers = [0,1,2,3]
    result = np.random.choice(numbers, p=weights)
    return result

if l=="python":
    name_list=["CSN-V","DEV","webqurey","transfer"]
else:
    name_list = ["CosBeach", "CSN-V", "NCSED","transfer"]
num=10
def to_txt():
    for n in name_list:
        with open("../../../dataset/eval_dataset/"+l+"/"+n+"/qurey.txt","r+",encoding="utf-8") as f:
            data=f.read().split('\n')[:100]
        with open("bertafter/"+l + "/"+n+"_bert_qurey.txt", "w+", encoding="utf-8") as f:
            with tqdm(total=len(data)) as pbar:
                for start_i in data:
                    pbar.update(1)
                    tmp=[]
                    for count in range(10):
                        predicted_token=start_i
                        lst = start_i.split(" ")
                        seq = '[MASK]'
                        new_lst = [val for pair in zip([seq] * len(lst), lst) for val in pair] + [seq]
                        input_ids = tokenizer.encode(" ".join(new_lst), return_tensors='tf')
                        while len(input_ids[0])<20:
                            outputs = model(input_ids)
                            mask_index = tf.squeeze(tf.where(input_ids == tokenizer.mask_token_id)).numpy()[:,-1].tolist()
                            predicted_index = tf.argsort(outputs[0],direction='DESCENDING')[0,:,getrandom_num()].numpy().tolist()
                            out=tf.squeeze(input_ids).numpy().tolist()
                            for i in mask_index:
                                out[i]=predicted_index[i]

                            predicted_token=re.sub("[?]","",tokenizer.decode(out[1:-1]))
                            text=predicted_token.split(" ")
                            new_lst = [val for pair in zip([seq] * len(text), text) for val in pair] + [seq]
                            input_ids = tokenizer.encode(" ".join(new_lst), return_tensors='tf')
                        tmp.append(re.sub("[\n]","",predicted_token))

                    f.write("==========".join(tmp)+"\n")
                    f.flush()

def to_np():
    tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
    def tokenit(txt):
        txt=txt.lower()
        return [re.sub("Ġ","",i) for i in tokenizer.tokenize(txt)]
    with open("../../../dataset/train_data/"+l+"/docstring_tokens_vocab.txt", "r+", encoding="utf-8") as f:
        vocab = f.read().split("\n")
        vocab_tokern2id = {vocab[i]: i for i in range(len(vocab))}
    for n in name_list:
        for index in range(10):
            with open("bertafter/"+l + "/"+n+"_bert_qurey.txt", "r+", encoding="utf-8") as f:
                data=[]
                for i in f.read().split('\n')[:-1]:
                    tmp=i.split("==========")
                    if (len(tmp)<=index):
                        data.append(tmp[0])
                        break
                    data.append(tmp[index])
            data1=[]
            for txt in tqdm(data):
                data1.append([vocab_tokern2id.get(i,1) for i in tokenit(txt)])

            data = tf.keras.preprocessing.sequence.pad_sequences(data1,
                                                                 maxlen=60, padding='post',
                                                                 truncating='post', value=0)
            np.save(os.path.join(os.path.join(os.path.join("bertafter",l) , n+'_bert_qurey_'+str(index))), data)
#to_txt()
to_np()