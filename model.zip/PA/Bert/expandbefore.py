import os
import re
import warnings

import numpy as np

warnings.filterwarnings("ignore")

import tensorflow as tf
from tqdm import tqdm
from transformers import BertTokenizer, TFBertForMaskedLM,RobertaTokenizer

model_name = 'bert-base-uncased'
tokenizer = BertTokenizer.from_pretrained(model_name)
model = TFBertForMaskedLM.from_pretrained(model_name)

l='java'

if l=="python":
    name_list=["CSN-V","DEV","webqurey","transfer"]
else:
    name_list = ["CosBeach", "CSN-V", "NCSED","transfer"]
num=10
def to_txt():
    for n in name_list:
        with open("../../../dataset/eval_dataset/"+l+"/"+n+"/qurey.txt","r+",encoding="utf-8") as f:
            data=f.read().split('\n')[:100]
        with open("bertbefore/"+l + "/"+n+"_bert_qurey.txt", "w+", encoding="utf-8") as f:
            with tqdm(total=len(data)) as pbar:
                for i in data:
                    pbar.update(1)
                    lst = i.split(" ")
                    seq = '[MASK]'
                    new_lst = [val for pair in zip([seq] * len(lst), lst) for val in pair] + [seq]
                    input_ids = tokenizer.encode(" ".join(new_lst), return_tensors='tf')
                    if len(input_ids[0])<40:
                        outputs = model(input_ids)
                        mask_index = tf.squeeze(tf.where(input_ids == tokenizer.mask_token_id)).numpy()[:,-1].tolist()
                        predicted_index = tf.argmax(outputs[0], axis=-1)[0].numpy().tolist()
                        out=tf.squeeze(input_ids).numpy().tolist()
                        for i in mask_index:
                            out[i]=predicted_index[i]
                        predicted_token = tokenizer.decode(out[1:-1])
                       
                       
                        generated_text =predicted_token
                    else:
                        generated_text = i
                    f.write(re.sub("\n","",generated_text)+"\n")
                    f.flush()

def to_np():
    tokenizer = RobertaTokenizer.from_pretrained('roberta-base', do_lower_case=True)
    def tokenit(txt):
        txt=txt.lower()
        return [re.sub("Ġ","",i) for i in tokenizer.tokenize(txt)]
    with open("../../../dataset/train_data/"+l+"/docstring_tokens_vocab.txt", "r+", encoding="utf-8") as f:
        vocab = f.read().split("\n")
        vocab_tokern2id = {vocab[i]: i for i in range(len(vocab))}
    for n in name_list:
        for index in range(10):
            with open("bertbefore/"+l + "/"+n+"_bert_qurey.txt", "r+", encoding="utf-8") as f:
                data=[]
                for i in f.read().split('\n')[:-1]:
                    tmp=i.split("==========")
                    if (len(tmp)<=index):
                        data.append(tmp[0])
                        break
                    data.append(tmp[index])
            data1=[]
            for txt in tqdm(data):
                data1.append([vocab_tokern2id.get(i,1) for i in tokenit(txt)])

            data = tf.keras.preprocessing.sequence.pad_sequences(data1,
                                                                 maxlen=60, padding='post',
                                                                 truncating='post', value=0)
            np.save(os.path.join(os.path.join(os.path.join("bertbefore",l) , n+'_bert_qurey_'+str(index))), data)
to_txt()
to_np()