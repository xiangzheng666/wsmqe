from transformers import BertTokenizer, TFBertForMaskedLM
import tensorflow as tf
import numpy as np
gpus = tf.config.list_physical_devices('GPU')
tf.config.set_visible_devices(gpus[1], 'GPU')
def getrandom_num():
    probabilities = [1, 0.6, 0.5, 0.4]
    weights = 1 / np.array(probabilities)
    weights = weights / np.sum(weights)
    numbers = [0,1,2,3]
    result = np.random.choice(numbers, p=weights)
    return result
def call_back():
    text = "[MASK] convert [MASK] int [MASK] to [MASK] str [MASK]."
    input_ids = tokenizer.encode(text, add_special_tokens=True, return_tensors='tf')
    outputs = model(input_ids)
    mask_index = tf.squeeze(tf.where(input_ids == tokenizer.mask_token_id)).numpy()[:,-1].tolist()
    predicted_index = tf.argsort(outputs[0],direction='DESCENDING')[0,:,getrandom_num()].numpy().tolist()

    out=tf.squeeze(input_ids).numpy().tolist()
    for i in mask_index:
        out[i]=predicted_index[i]
    predicted_token = tokenizer.decode(out[1:-1])
    print('origin token: convert int to str')
    print('==================Predicted token:', predicted_token)
    

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = TFBertForMaskedLM.from_pretrained("bertmodel/last_model")
call_back()

import numpy as np
a=np.load("bertafter/python/CSN-V_bert_qurey_1.npy")
print(a.shape)